INSERT INTO `user` VALUES (1, '123456', 'zy', '5555555@qq.com', NULL, '2024-12-05 15:28:00', '2024-12-05 15:28:00');
INSERT INTO `user` VALUES (2, 'e10adc3949ba59abbe56e057f20f883e', 'w', '123456@qq.com', NULL, '2024-12-05 15:28:00', '2024-12-05 15:28:00');
INSERT INTO `user` VALUES (4, 'e10adc3949ba59abbe56e057f20f883e', 'w', '1234567@qq.com', NULL, '2024-12-05 15:28:57', '2024-12-05 15:28:57');
INSERT INTO `user` VALUES (5, 'e10adc3949ba59abbe56e057f20f883e', 'wp', '12345689@qq.com', NULL, '2024-12-05 16:39:42', '2024-12-05 16:39:42');
INSERT INTO `user` VALUES (8, 'e10adc3949ba59abbe56e057f20f883e', '杰洛·齐贝林', '519554004@qq.com', 'http://localhost:9000/mhban/65c9e103-f8c8-4d22-ac15-7a90ec022dbb.jpg', '2025-01-30 17:25:25', '2025-03-05 12:45:11');
INSERT INTO `user` VALUES (9, 'e10adc3949ba59abbe56e057f20f883e', 'longlong', '1500140527@qq.com', 'http://localhost:9000/mhban/23c09f3d-e7ee-4a6d-95de-d0785ebaafe1.jpg', '2025-02-20 18:48:28', '2025-03-05 13:15:04');
INSERT INTO `user` VALUES (10, 'e10adc3949ba59abbe56e057f20f883e', 'blank', '2698114475@qq.com', 'http://localhost:9000/mhban/f62b7bad-9fdf-4722-a6f2-61300fa9255c.jpg', '2025-03-05 12:48:01', '2025-03-05 12:53:28');
