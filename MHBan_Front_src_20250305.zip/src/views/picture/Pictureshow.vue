<template>
    <div>
      <h1>{{ '图片序列号： ' + picture.id }}</h1>
      <div class="image-container">
        <img :src="picture.picurl" alt="图片" class="detail-image" @click="openOriginalImage(picture.picurl)">
      </div>
      <p>图片主题: {{ picture.title }}</p>
      <p>图片作者: {{ picture.userId }}</p>
      <p>图片尺寸: {{ picture.width + 'x' + picture.height }}</p>
      <p>创建时间: {{ picture.createTime }}</p>

    </div>
</template>

<script setup>

import { ref } from 'vue';
import pictureInfoStore from '@/stores/picinfo.js'
const picinfostore = pictureInfoStore();

const picture = ref(picinfostore.info);

const dialogVisible = ref(false);
const originalImageUrl = ref('');

const showOriginalImage = (url) => {
  originalImageUrl.value = url;
  dialogVisible.value = true;
};

const openOriginalImage = (url) => {
  window.open(url, '_blank');
};
</script>

<style scoped>
.image-container {
  width: 800px; /* 设置图片容器宽度为 800px */
  margin: 0 auto; /* 水平居中容器 */
}

.detail-image {
  width: 100%; /* 图片宽度填充容器 */
  height: auto; /* 高度自适应，保持图片比例 */
  display: block; /* 去除图片底部的额外间距 */
}

</style>