  <script setup>
  import { ref, onMounted } from 'vue';
  import {pictureMineGetService} from '@/api/picture.js'
  import {ElMessage,ElMessageBox} from 'element-plus'
  // 定义存储图片信息的响应式数组
  const pictures = ref([]);
  
  // 模拟从后端获取图片信息的函数
  const fetchPictures = async () => {
    let result = await pictureMineGetService();
    pictures.value = result.data;
  };
  
  // 在组件挂载时调用获取图片信息的函数
  onMounted(() => {
    fetchPictures();
  });
  
  import { useRouter } from 'vue-router';
  const router = useRouter();
  
  import pictureInfoStore from '@/stores/picinfo.js'
  const picinfostore = pictureInfoStore();
  
  const handlePictureClick = (picture) => {
  
  picinfostore.setInfo(picture);
  
  router.push({ path: '/picture/info'});
  };
  
//图片上传
import {Plus} from '@element-plus/icons-vue'
//控制抽屉是否显示
const visibleDrawer = ref(false)
//添加表单数据模型
const picturedata = ref({
    picurl: '',
    title: '',
    width: 0,
    height: 0
})
// 定义验证规则
const rules = {
  title: [
    { required: true, message: '标题不能为空', trigger: 'blur' },
    { min: 1, max: 100, message: '标题长度必须在 1 到 100 个字符之间', trigger: 'blur' }
  ]
};

import { useTokenStore } from '@/stores/token.js'
const tokenStore = useTokenStore()

//图片上传成功的回调
const uploadSuccess = (result)=>{
    //回显图片
    picturedata.value.picurl = result.data 

 // 创建一个 Image 对象
 const img = new Image();
    img.src = picturedata.value.picurl;

    img.onload = () => {
        // 获取图片的宽度和高度
        picturedata.value.width = img.naturalWidth;
        picturedata.value.height = img.naturalHeight;
    };

    // 监听图片加载失败事件
    img.onerror = () => {
        console.error('图片加载失败');
    };
}

import { pictureUploadService }from '@/api/picture.js'
const uploadPicture = async()=>{
  let result = await pictureUploadService(picturedata.value)
    ElMessage.success(result.message? result.message:'上传成功')
    visibleDrawer.value=false
    fetchPictures();
}
  </script>

<template>
  <div id="app">
    <el-card class="image-container">
      <template #header>
        <div class="header">
          <span>我的图片</span>
          <!-- 添加上传图片按钮 -->
          <el-button type="primary" @click="visibleDrawer = true">上传图片</el-button>
        </div>
      </template>
      <el-row>
        <!-- 使用 v-for 指令循环渲染图片 -->
        <el-col :span="6" v-for="(picture, index) in pictures" :key="index">
          <el-card class="image-card"  @click="handlePictureClick(picture)">
            <template #header>
              <div class="image-header">
                <span>{{ '主题： '+picture.title }}</span>
              </div>
            </template>
            <!-- 显示图片 -->
            <div class="image-wrapper">
              <img :src="picture.picurl" alt="图片" class="image">
            </div>
            <div class="image-info">
              <p>图片序列号: {{ ' '+picture.id }}</p>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </el-card>
  </div>

   <!-- 抽屉 -->
   <el-drawer v-model="visibleDrawer" title="添加图片" direction="rtl" size="50%">
            <!-- 添加文章表单 -->
            <el-form :model="picturedata" :rules="rules" label-width="100px" >
                <el-form-item label="图片主题" prop="title">
                    <el-input v-model="picturedata.title" placeholder="请输入主题"></el-input>
                </el-form-item>
               
                <el-form-item label="上传图片">

                    <el-upload
                     class="avatar-uploader" 
                     :auto-upload="true" 
                     :show-file-list="false"
                     action="/api/upload"
                     name="file"
           :headers="{'Authorization':tokenStore.token}"
           :on-success="uploadSuccess"
                     >
                        <img v-if="picturedata.picurl" :src="picturedata.picurl" class="avatar" />
                        <el-icon v-else class="avatar-uploader-icon">
                            <Plus />
                        </el-icon>
                    </el-upload>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="uploadPicture">上传</el-button>
                </el-form-item>
            </el-form>
        </el-drawer>

</template>

<style lang="scss" scoped>
.image-container {
  margin: 20px;
}

.image-card {
  /* 设置图片卡片的固定高度 */
  height: 350px;
}

.image-wrapper {
  /* 设置图片包裹层的高度和宽度 */
  height: 200px;
  width: 100%;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
}

.image {
  /* 让图片适应包裹层 */
  min-width: 100%;
  min-height: 100%;
  object-fit: cover;
}

.image-header {
  text-align: center;
}

.image-info {
  padding: 10px;
}

.avatar-uploader {
    :deep() {
        .avatar {
            width: 178px;
            height: 178px;
            display: block;
        }

        .el-upload {
            border: 1px dashed var(--el-border-color);
            border-radius: 6px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: var(--el-transition-duration-fast);
        }

        .el-upload:hover {
            border-color: var(--el-color-primary);
        }

        .el-icon.avatar-uploader-icon {
            font-size: 28px;
            color: #8c939d;
            width: 178px;
            height: 178px;
            text-align: center;
        }
    }
}
.editor {
  width: 100%;
  :deep(.ql-editor) {
    min-height: 200px;
  }
}

</style>