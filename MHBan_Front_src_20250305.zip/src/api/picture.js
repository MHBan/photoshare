import request from '@/utils/request.js'
//获取个人信息
export const pictureListGetService = ()=>{
    return request.get('/picture/list');
}

export const pictureMineGetService = ()=>{
    return request.get('/picture/mine');
}

export const pictureUploadService = (pictureData)=>{
    const params =new URLSearchParams()
    for(let key in pictureData){
        params.append(key,pictureData[key]);
    }
return request.post('/picture/create',params);
} 

//获取相应主题图片
export const pictureSearchService = (title)=>{
    return request.get('/picture/search',{
        params: {
          title
        }
      }
    );
}