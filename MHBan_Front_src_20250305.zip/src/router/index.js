import { createRouter,createWebHistory } from "vue-router"

import LoginVue from '@/views/Login.vue'
import LayoutVue from '@/views/Layout.vue'

import UserInfoVue from '@/views/user/UserInfo.vue'
import UserAvatarVue from '@/views/user/UserAvatar.vue'
import UserResetPasswordVue from '@/views/user/UserResetPassword.vue'

import HomeVue from '@/views/picture/home.vue'
import PictureSearchVue from '@/views/picture/PictureSearch.vue'
import PictureMineVue from '@/views/picture/PictureMine.vue'
import PictureShowVue from '@/views/picture/Pictureshow.vue'
                                   

const routes = [
    {path:'/login',component: LoginVue},
    {path:'/',
        component: LayoutVue,
     //重定向
     redirect: '/picture/home', 
     //子路由
     children: [
        { path: '/picture/home', component: HomeVue },
         { path: '/picture/search', component: PictureSearchVue },
         { path: '/picture/mine', component: PictureMineVue },
         { path: '/picture/info', component: PictureShowVue },
        
         { path: '/user/info', component: UserInfoVue },
         { path: '/user/avatar', component: UserAvatarVue },
         { path: '/user/password', component: UserResetPasswordVue },
     ]
    }
]

const router = createRouter({
    history:createWebHistory(),
    routes:routes
})

export default router