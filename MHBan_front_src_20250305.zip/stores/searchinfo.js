import { defineStore } from "pinia"
import {ref} from 'vue'

const searchInfoStore = defineStore('searchInfo',()=>{
    //1.定义信息
    const info = ref({})
    //2.定义修改信息的方法
    const setInfo = (newInfo)=>{
        info.value = newInfo
    }
    //3.定义清空信息的方法
    const removeInfo = ()=>{
        info.value={}
    }

    return{info,setInfo,removeInfo}
},{
    persist:true
})

export default searchInfoStore;