<template>
    <div id="app">
      <el-card class="image-container">
        
        <template #header>
          <div class="header">
            <span>主题： {{ searchStore.info }}</span>
          </div>
        </template>
        <el-row>
          <!-- 使用 v-for 指令循环渲染图片 -->
          <el-col :span="6" v-for="(picture, index) in pictures" :key="index">
            <el-card class="image-card" @click="handlePictureClick(picture)">
              <template #header>
                <div class="image-header">
                  <span>{{ picture.title }}</span>
                </div>
              </template>
              <!-- 显示图片 -->
              <div class="image-wrapper">
                <img :src="picture.picurl" alt="图片" class="image">
              </div>
              <div class="image-info">
                <p>图片序列号: {{ picture.id }}</p>               
              </div>
            </el-card>
          </el-col>
        </el-row>
      </el-card>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted ,watch } from 'vue';

  import {pictureSearchService} from '@/api/picture.js'
  import searchInfoStore from '@/stores/searchinfo.js';

  const searchStore = searchInfoStore();
  // 定义存储图片信息的响应式数组
  const pictures = ref([]);
  
  // 模拟从后端获取图片信息的函数
  const fetchPictures = async () => {
    const title = searchStore.info
    let result = await pictureSearchService(title);
  
    pictures.value = result.data;
  
  };
  
  // 在组件挂载时调用获取图片信息的函数
  onMounted(() => {
    fetchPictures();
  });

// 监听 searchStore 的变化
watch(
    () => searchStore.info,
    (newValue, oldValue) => {
      if (newValue!== oldValue) {
        fetchPictures();
      }
    }
  );

//点击图片进入详细页面
import { useRouter } from 'vue-router';
const router = useRouter();

import pictureInfoStore from '@/stores/picinfo.js'
const picinfostore = pictureInfoStore();

const handlePictureClick = (picture) => {

picinfostore.setInfo(picture);

router.push({ path: '/picture/info'});
};

  </script>
  
  <style scoped>
  .image-container {
    margin: 20px;
  }
  
  .image-card {
    /* 设置图片卡片的固定高度 */
    height: 350px;
  }
  
  .image-wrapper {
    /* 设置图片包裹层的高度和宽度 */
    height: 200px;
    width: 100%;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .image {
    /* 让图片适应包裹层 */
    min-width: 100%;
    min-height: 100%;
    object-fit: cover;
  }
  
  .image-header {
    text-align: center;
  }
  
  .image-info {
    padding: 10px;
  }
  </style>