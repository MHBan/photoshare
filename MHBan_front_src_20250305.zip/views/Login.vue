<script setup>
import { User, Lock } from '@element-plus/icons-vue'
import { ref } from 'vue'
import { useTokenStore } from '@/stores/token.js'
import {ElMessage,ElMessageBox} from 'element-plus'
//控制注册与登录表单的显示， 默认显示注册
const isRegister = ref(false)
const status = ref('0')

const tokenStore = useTokenStore();

//注册接口数据
const registerData = ref({
name:'',
password:'',
rePassword:'',
email:'',
states:status,
code:''
}) 

//登录接口数据
const loginData = ref({
email:'',
password:''
}) 

//校验重复密码函数
const checkRePassword = (rule,value,callback)=>{
    if(value === '') callback(new Error('确认密码不可为空'))
    else if(value !== registerData.value.password) callback(new Error('两次输入密码不匹配'))
else callback()
}

//注册表单校验规则
const registerrules={
    name:[
        {required:true,message:'请输入用户名',trigger:'blur'},
        {min:1, max:25,message:'长度为1~25位非空字符',trigger:'blur'}
    ],
password:[{required:true,message:'请输入密码',trigger:'blur'},
{min:6, max:16,message:'长度为6~16位非空字符',trigger:'blur'}
],
rePassword:[{
    validator:checkRePassword,trigger:'blur'
}],
email:[
        { required: true, message: '请输入邮箱', trigger: 'blur' },
        { type: 'email', message: '请输入正确的邮箱格式', trigger: ['blur', 'change'] }
    ]
}

//登录表单
const loginrules={
   email:[
        { required: true, message: '请输入邮箱', trigger: 'blur' },
        { type: 'email', message: '请输入正确的邮箱格式', trigger: ['blur', 'change'] }
    ],
password:[{required:true,message:'请输入密码',trigger:'blur'},
{min:6, max:16,message:'长度为6~16位非空字符',trigger:'blur'}
]
}

import {userRegisterService , userLoginService} from '@/api/user.js'
//调用后台接口，完成注册
const register = async()=>{
 let result = await userRegisterService(registerData.value);
 if(result.code === -1){
    alert(result.data ? result.data:'注意查收验证码');
    // 发送成功后将 register.states 变为 1
    status.value = '1';
 }
 else if(result.code === 0){
    alert(result.message ? result.message:'注册成功');
    status.value = '0';
 }else{
    alert(result.message ? result.message:'系统错误');
    status.value = '0';
 }
}

//路由控制跳转页面
import { useRouter } from 'vue-router'
const router = useRouter()

//登录接口调用
const loadstart = async()=>{
 let result = await userLoginService(loginData.value);
 
 if(result.code === 0){
   
    tokenStore.setToken(result.data)
     router.push('/');
 }
 else{
    alert(result.message ? result.message:'系统错误');
 }
}
</script>

<template>
    <el-row class="login-page">      
        <el-col :span="6" :offset="3" class="form">
            <!-- 注册表单 -->
            <el-form ref="form" size="large" autocomplete="off" v-if="isRegister" :model="registerData" :rules="registerrules">
                <el-form-item>
                    <h1>注册</h1>
                </el-form-item>
                <el-form-item prop="name">
                    <el-input :prefix-icon="User" placeholder="请输入你想要的昵称" v-model="registerData.name"></el-input>
                </el-form-item>
                
                <el-form-item prop="email">
                    <el-input :prefix-icon="User" placeholder="请输入Email" v-model="registerData.email"></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input :prefix-icon="Lock" type="password" placeholder="请输入密码" v-model="registerData.password"></el-input>
                </el-form-item>
                <el-form-item prop="rePassword">
                    <el-input :prefix-icon="Lock" type="password" placeholder="请输入再次密码" v-model="registerData.rePassword"></el-input>
                </el-form-item>
                <el-form-item>
                <div class="input-button-wrapper">
                        <el-input :prefix-icon="Bell" placeholder="请输入验证码" v-model="registerData.code"></el-input>
                        <el-button class="button01" type="primary" auto-insert-space @click="register">
                            获取验证码
                        </el-button>
                    </div>
                </el-form-item>

                <!-- 注册按钮 -->
                <el-form-item>
                    <el-button class="button" type="primary" auto-insert-space @click="register">
                        注册
                    </el-button>
                </el-form-item>
                <el-form-item class="flex">
                    <el-link type="info" :underline="false" @click="isRegister = false">
                        ← 返回
                    </el-link>
                </el-form-item>
            </el-form>
            <!-- 登录表单 -->
            <el-form ref="form" size="large" autocomplete="off" :model="loginData" :rules="loginrules" v-else>
                <el-form-item>
                    <h1>登录</h1>
                </el-form-item>
                <el-form-item prop="email">
                    <el-input :prefix-icon="User" placeholder="请输入email" v-model="loginData.email"></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input name="password" :prefix-icon="Lock" type="password" placeholder="请输入密码" v-model="loginData.password"></el-input>
                </el-form-item>
                <el-form-item class="flex">
                    <div class="flex">
                        <el-checkbox>记住我</el-checkbox>
                        <el-link type="primary" :underline="false">忘记密码？</el-link>
                    </div>
                </el-form-item>
                <!-- 登录按钮 -->
                <el-form-item>
                    <el-button class="button" type="primary" auto-insert-space @click="loadstart"> 
                        登录
                    </el-button>
                </el-form-item>
                <el-form-item class="flex">
                    <el-link type="info" :underline="false" @click="isRegister = true">
                        注册 →
                    </el-link>
                </el-form-item>
            </el-form>
        </el-col>
    </el-row>
</template>

<style lang="scss" scoped>
/* 样式 */
.login-page {
    height: 100vh;
            width: 100%;
        background: 
            url('@/assets/login_bg.jpg') no-repeat center/ cover ;
           
          
        border-radius: 20px 20px 20px 20px;
    

    .form {
        display: flex;
        flex-direction: column;
        justify-content: center;
        user-select: none;

        .title {
            margin: 0 auto;
        }

        h1 {
        color: white; /* 标题文字设为白色 */
    }


        .button {
            width: 100%;
        }

        .button01{
            width: 20%;
        }

        .input-button-wrapper {
        display: flex;
        gap: 20px; /* 设置输入框和按钮之间的间距 */
    }


        .flex {
            width: 100%;
            display: flex;
            justify-content: space-between;
        }
    }

}
</style>