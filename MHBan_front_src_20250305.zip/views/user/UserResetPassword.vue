<script setup>
import { ref } from 'vue'
import {ElMessage,ElMessageBox} from 'element-plus'
//路由控制跳转页面
import { useRouter } from 'vue-router'
const router = useRouter()
import { useTokenStore } from '@/stores/token.js'
const tokenStore = useTokenStore()
//导入pinia
import useUserInfoStore from '@/stores/userinfo.js'
const userInfoStore = useUserInfoStore();
//登录接口数据
const passwordData = ref({
oldPwd:'',
newPwd:'',
rePwd:''
}) 

//校验重复密码函数
const checkRePassword = (rule,value,callback)=>{
    if(value === '') callback(new Error('确认密码不可为空'))
    else if(value !== passwordData.value.newPwd) callback(new Error('两次输入密码不匹配'))
else callback()
}

//注册表单校验规则
const rules={
   
oldPwd:[{required:true,message:'请输入原来的密码',trigger:'blur'},
{min:6, max:16,message:'长度为6~16位非空字符',trigger:'blur'}
],

newPwd:[{required:true,message:'请输入新密码',trigger:'blur'},
{min:6, max:16,message:'长度为6~16位非空字符',trigger:'blur'}
]
,
rePwd:[{
    validator:checkRePassword,trigger:'blur'
}]
}

import { userResetPasswordService } from '@/api/user.js'

const isLoading = ref(false) // 添加 loading 状态

const resetPassword = async () => {
    if (isLoading.value) return // 如果正在加载，直接返回
    try {
        const confirmResult = await ElMessageBox.confirm(
            '你确认要修改密码吗？',
            '温馨提示',
            {
                confirmButtonText: '确认',
                cancelButtonText: '取消',
                type: 'warning',
            }
        )
        isLoading.value = true // 开始加载
        
        let result = await userResetPasswordService(passwordData.value);
        
        if (result.code === 0) {
            userInfoStore.info = {}
            tokenStore.token = ''
            router.push('/login')
        } else {
            ElMessage.error(result.message? result.message : '修改失败')
        }
    } catch (error) {
        if (error.name === 'cancel') {
            ElMessage({
                type: 'info',
                message: '取消修改',
            })
        } else {
            ElMessage.error('请求出错，请稍后重试')
        }
    } finally {
        isLoading.value = false // 结束加载
    }
}

</script>

<template>
    <el-card class="page-container">
        <template #header>
            <div class="header">
                <span>密码修改</span>
            </div>
        </template>
        <el-row>
            <el-col :span="12">
                <el-form :model="passwordData" :rules="rules" label-width="100px" size="large">
                    <el-form-item label="旧密码" prop="oldPwd">
                        <el-input placeholder="请输入原来的密码" v-model="passwordData.oldPwd"></el-input>
                    </el-form-item>
                    <el-form-item label="新密码" prop="newPwd">
                        <el-input placeholder="请输入新的密码" v-model="passwordData.newPwd"></el-input>
                    </el-form-item>
                    <el-form-item label="确认密码" prop="rePwd">
                        <el-input placeholder="请确认密码" v-model="passwordData.rePwd"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="resetPassword" :loading="isLoading">提交修改</el-button>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
    </el-card>
</template>