package com.test.componentclass;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import java.util.Random;
import java.util.concurrent.TimeUnit;


@Data
@Component
public class hostEmail {

    private static final int CODE_LENGTH = 6;
    private static final long CODE_EXPIRATION_SECONDS = 300; // 验证码有效期，5分钟（300秒）
    @Value("${spring.mail.username}")
    private String Fromemail;

    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    public void sendVerificationCode(String toEmail) {
        // 生成验证码
        String verificationCode = generateVerificationCode();
        // 发送邮件
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(Fromemail);
        message.setTo(toEmail);
        message.setSubject("注册验证码");
        message.setText("您好，您的注册验证码是：" + verificationCode + "，有效期为5分钟，请尽快使用。");
        javaMailSender.send(message);
        System.out.println("验证码: "+verificationCode);
        // 将验证码存入Redis，并设置有效期
        redisTemplate.opsForValue().set(toEmail, verificationCode, CODE_EXPIRATION_SECONDS, TimeUnit.SECONDS);
    }

    private String generateVerificationCode() {
        Random random = new Random();
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < CODE_LENGTH; i++) {
            code.append(random.nextInt(10));
        }
        return code.toString();
    }

    public boolean checkVerificationCode(String email,String code){
        String storedCode = redisTemplate.opsForValue().get(email);
        if (storedCode!= null && storedCode.equals(code)) {
            // 验证通过后，可选择删除Redis中的验证码（此处删除）
            redisTemplate.delete(email);
            return true;
        }
        return false;
    }

}
