package com.test.controller;

import com.test.pojo.Result;
import com.test.pojo.User;
import com.test.service.UserService;
import com.test.componentclass.hostEmail;
import com.test.utils.JwtUtil;
import com.test.utils.Md5Util;
import com.test.utils.ThreadLocalUtil;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Validated
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private hostEmail hostemail;
    @Autowired
    StringRedisTemplate stringRedisTemplate;

    @PostMapping("/register")
    public Result register(@Pattern(regexp = "^\\S{1,25}$") String name, @Pattern(regexp = "^\\S{6,16}$") String password, @Email String email, String states, String code) {
        User u = userService.findByEmail(email);
        if (u == null) {
            if (states.equals("1")) {
                userService.register(name, password, email, code);
                return Result.success();
            } else if (states.equals("0")) {
                hostemail.sendVerificationCode(email);
                return Result.success(-1,"验证码已发送");
            }
            return Result.error("系统出错");
        } else {
            return Result.error("邮箱已被注册");
        }
    }

    @PostMapping("/login")
    public Result<String> login(@Email String email, @Pattern(regexp = "^\\S{6,16}$") String password) {
        User byEmail = userService.findByEmail(email);
        if (byEmail == null) return Result.error("用户不存在");
        if (!Md5Util.getMD5String(password).equals(byEmail.getPassword())) {
            return Result.error("密码错误");
        }

        else{
            Map<String, Object> claims = new HashMap<>();
            claims.put("id", byEmail.getId());
            claims.put("email", byEmail.getEmail());
            String genToken = JwtUtil.genToken(claims);

            //redis
            ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
            ops.set(genToken,genToken,1, TimeUnit.HOURS);

            return Result.success(genToken);
        }

    }

    @GetMapping("/userInfo")
    public Result<User> userInfo() {

        Map<String, Object> map = ThreadLocalUtil.get();
        String email = (String) map.get("email");

        User u = userService.findByEmail(email);
        return Result.success(u);
    }

    @PutMapping("/update")
    public Result update(@RequestBody @Validated User u){
        userService.update(u);
        return Result.success();
    }

    @PatchMapping("/updatePwd")
     public Result updatePwd(@RequestBody Map<String,String>params,@RequestHeader("Authorization") String token){

        String oldPwd=params.get("oldPwd");
        String newPwd=params.get("newPwd");
        String rePwd=params.get("rePwd");

if(!StringUtils.hasLength(oldPwd)||!StringUtils.hasLength(newPwd)||!StringUtils.hasLength(rePwd)){
    return Result.error("缺少必要参数");
}

if(!newPwd.equals(rePwd)) return Result.error("新密码填写不一致");

Map<String,Object>map=ThreadLocalUtil.get();
String email=(String) map.get("email");
User loginUser=userService.findByEmail(email);
if(!loginUser.getPassword().equals(Md5Util.getMD5String(oldPwd))){
    return Result.error("原密码错误");
}

userService.updatePwd(newPwd);

//redis删除对应token
        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
        ops.getOperations().delete(token);

return Result.success();

    }

    @PatchMapping("/updateAvatar")
    public Result updateAvatar(@RequestParam String avatar){
        userService.updateAvatar(avatar);
        return Result.success();
    }

}
