package com.test.controller;

import com.test.pojo.Result;
import com.test.utils.MinioUtil;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import java.util.UUID;

@RestController
public class FileUploadController {

    @PostMapping("/upload")
    public Result<String> upload(MultipartFile file) throws Exception {
        if(file==null) return Result.error("图片不能为空");

        String originalFilename = file.getOriginalFilename();
        String filename= UUID.randomUUID()+originalFilename.substring(originalFilename.lastIndexOf("."));
        String picurl= MinioUtil.upload(filename,file);

        if(picurl!=null) {
            return Result.success(picurl);
        }
        else {
            return Result.error("picurl is null");
        }

    }

}
