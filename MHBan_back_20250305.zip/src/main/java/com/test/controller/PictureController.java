package com.test.controller;


import com.test.pojo.Picture;
import com.test.pojo.Result;
import com.test.service.PictureService;

import com.test.utils.ThreadLocalUtil;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;

import org.hibernate.validator.constraints.URL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Map;


@Validated
@RestController
@RequestMapping("/picture")
public class PictureController {

    @Autowired
    private PictureService pictureService;

    @GetMapping("/list")
    public Result<List<Picture>> list(){
        List<Picture> p=pictureService.allpicture();
        return Result.success(p);
    }

    @GetMapping("/search")
    public Result<List<Picture>> search(String title){
        System.out.println(title+"......");
        List<Picture> pictures=pictureService.findbytag(title);
if(pictures!=null){
    return Result.success(pictures);
}
return Result.error("未发现相关内容");
    }

    @GetMapping("/mine")
    public Result<List<Picture>> searchbyuser(){
        Map<String,Object> map= ThreadLocalUtil.get();
        Integer userId=(Integer) map.get("id");
        List<Picture> pictures=pictureService.searchbyuser(userId);
            return Result.success(pictures);
    }

    @PostMapping("/create")
    public Result<String> createpic(@URL String picurl, @Pattern(regexp = "^\\S{1,100}$")String title,Integer width,Integer height) throws Exception {

        Map<String,Object> map= ThreadLocalUtil.get();
        Integer userId=(Integer) map.get("id");

            pictureService.createpicture(picurl, title, userId, width, height);

        return Result.success("图片上传成功");
    }

    @DeleteMapping("/delete")
    public Result<String> deletepic(@NotEmpty Integer id,Integer userid){
        Map<String,Object> map= ThreadLocalUtil.get();
        Integer userId=(Integer) map.get("id");
        if(userid!=userId) return Result.error("这张图片不属于你");
        pictureService.deletepic(id);
        return Result.success("pic delete");
    }

}
