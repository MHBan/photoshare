package com.test.controller;

import com.test.pojo.Article;
import com.test.pojo.Result;
import com.test.service.ArticleService;
import com.test.utils.ThreadLocalUtil;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import org.hibernate.validator.constraints.URL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Validated
@RestController
@RequestMapping("/article")
public class ArticleController {

    @Autowired
    private ArticleService articleService;

    @GetMapping("/list")
    public Result<String> list(){
        return Result.success("all list show");
    }

@PostMapping("/categories")
    public Result<String> createcategories(){
        //后续补充
    return Result.success();
}


@PostMapping("/create")
    public Result<String> createarticle(@URL String picurl,@Pattern(regexp = "^\\S{1,100}$") String title,@NotEmpty String content){
        //获取uid
    Map<String,Object> map= ThreadLocalUtil.get();
    Integer userId=(Integer) map.get("id");
    Article article=articleService.findbyTitle(userId,title);
    if(article!=null) return Result.error("标题已存在");
    articleService.createArticle(picurl,title,content,userId);
    return Result.success();
}

@DeleteMapping("/delete")
    public Result<String> deletearticle(@Pattern(regexp = "^\\S{1,100}$") String title) {
    Map<String,Object> map= ThreadLocalUtil.get();
    Integer userId=(Integer) map.get("id");
    Article article=articleService.findbyTitle(userId,title);
    if(article!=null){
        articleService.deletebyId(article.getId());
        return Result.success();
    }
    return Result.error("文章不存在");
}

}
