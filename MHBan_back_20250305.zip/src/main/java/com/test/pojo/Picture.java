package com.test.pojo;

import lombok.Data;
import org.hibernate.validator.constraints.URL;

import java.time.LocalDateTime;

@Data
public class Picture {
    private Integer id;
    private String title;
    @URL
    private String picurl;
    private String picpath;
    private Integer categoryId;
    private Integer userId;
    private Integer width;
    private Integer height;
    private LocalDateTime createTime;
}
