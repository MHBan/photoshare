package com.test.pojo;


import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.hibernate.validator.constraints.URL;

import java.time.LocalDateTime;

@Data
public class Article {
    private Integer id;//主键ID
    @URL
    private String picurl;//封面图像
    //@NotEmpty
    @Pattern(regexp = "^S{1,100}$")
    private String title;//文章标题
    @NotEmpty
    private String content;//文章内容
    private Integer categoryId;//文章分类id
    @NotEmpty
    private Integer userId;//创建人ID
    private LocalDateTime createTime;//创建时间
}
