package com.test.pojo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Category {
    private Integer id;//主键ID
    private String name;//分类名称
    private String type;//是文章还是图片分类
    private Integer userid;//创建人ID
    private LocalDateTime createTime;//创建时间
}
