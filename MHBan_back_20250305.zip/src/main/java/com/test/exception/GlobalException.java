package com.test.exception;

import org.springframework.util.StringUtils;
import com.test.pojo.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalException {

    @ExceptionHandler(Exception.class)
    public Result handleException(Exception a){
        a.printStackTrace();
        return Result.error(StringUtils.hasLength(a.getMessage())?a.getMessage():"操作失败");
    }
}
