package com.test.utils;


import io.minio.*;
import io.minio.http.Method;
import org.springframework.web.multipart.MultipartFile;
import java.io.InputStream;




public class MinioUtil {


    private static final String AccessKey="MongoTransfer";

    private static final String SecretKey="XhKzCPvX";

    private static final String Url="http://localhost:9000";

    private static final String BucketName="mhban";


    public static String upload(String fileName,MultipartFile file) throws Exception{

        MinioClient minioClient=MinioClient.builder()
                .endpoint(Url)
                .credentials(AccessKey,SecretKey)
                .build();

        String url="";

        // 使用putObject上传一个文件到存储桶中。
        try {
            InputStream in=file.getInputStream();
            minioClient.putObject(
                    PutObjectArgs.builder()
                            .bucket(BucketName)
                            .object(fileName)
                            .stream(in, in.available(), -1)
                            .contentType(file.getContentType())
                            .build());
            url =Url+"/"+BucketName+"/"+fileName;

        } catch (Exception e) {
            e.printStackTrace();
        }
return url;
    }
}