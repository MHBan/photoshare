package com.test.service.impl;

import com.test.mapper.ArticleMapper;
import com.test.pojo.Article;
import com.test.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ArticleServiceImpl implements ArticleService {
@Autowired
private ArticleMapper articleMapper;

    @Override
    public Article findbyTitle(Integer userId, String title) {
        return articleMapper.findbyTitle(userId, title);
    }

    @Override
    public void createArticle(String picurl, String title, String content, Integer userId) {
       articleMapper.createArticle(picurl, title, content,  userId);
    }

    @Override
    public void deletebyId(Integer id) {
        articleMapper.deletebyId(id);
    }
}
