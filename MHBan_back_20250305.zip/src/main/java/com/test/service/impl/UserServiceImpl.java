package com.test.service.impl;

import com.test.mapper.UserMapper;
import com.test.pojo.User;
import com.test.service.UserService;
import com.test.componentclass.hostEmail;
import com.test.utils.Md5Util;
import com.test.utils.ThreadLocalUtil;
import jakarta.validation.constraints.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private hostEmail hostemail;
    @Override
    public User findByEmail(String email) {
      User u=userMapper.findByEmail(email);
        return u;
    }

    @Override
    public void register(String name, String password, String email,@Pattern(regexp = "^\\S{6}$")String code) {
        boolean isCodeValid = hostemail.checkVerificationCode(email,code);
if(isCodeValid) {
    String md5String = Md5Util.getMD5String(password);
    userMapper.add(name, md5String, email);
}else throw new RuntimeException("验证码错误，请重新输入！");
    }

    @Override
    public void update(User u) {
        u.setUpdateTime(LocalDateTime.now());
        userMapper.update(u);
    }

    @Override
    public void updatePwd(String newPwd) {
        Map<String,Object> map= ThreadLocalUtil.get();
        Integer id=(Integer) map.get("id");
        userMapper.updatePwd(Md5Util.getMD5String(newPwd),id);
    }

    @Override
    public void updateAvatar(String avatar) {
        Map<String,Object> map= ThreadLocalUtil.get();
        Integer userId=(Integer) map.get("id");
        userMapper.updateAcatar(avatar,userId);
    }

}
