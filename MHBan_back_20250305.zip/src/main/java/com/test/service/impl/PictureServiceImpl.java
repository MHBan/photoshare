package com.test.service.impl;

import com.test.mapper.PictureMapper;
import com.test.pojo.Picture;
import com.test.service.PictureService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PictureServiceImpl implements PictureService {

    @Autowired
    private PictureMapper pictureMapper;

    @Override
    public void createpicture(String picurl, String title, Integer userId,Integer width,Integer height) {
        pictureMapper.createpicture(picurl,title,userId, width, height);
    }

    @Override
    public void deletepic(Integer id) {
        pictureMapper.deletepic(id);
    }

    @Override
    public List<Picture> findbytag(String tag) {

        return pictureMapper.findbytag(tag);
    }

    @Override
    public List<Picture> allpicture() {
        return pictureMapper.allpicture();
    }

    @Override
    public List<Picture> searchbyuser(Integer userId) {
        return pictureMapper.searchbyuser(userId);
    }
}
