package com.test.service;

import com.test.pojo.Article;

public interface ArticleService {
    Article findbyTitle(Integer userId,String title);

void createArticle(String picurl,String title,String content,Integer userId);


    void deletebyId(Integer id);
}
