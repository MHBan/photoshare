package com.test.service;

import com.test.pojo.User;

public interface UserService {
    User findByEmail(String email);

    void register(String name, String password, String email,String code);


    void update(User u);

    void updatePwd(String newPwd);

    void updateAvatar(String avatar);
}
