package com.test.service;

import com.test.pojo.Picture;

import java.util.List;

public interface PictureService {
    void createpicture(String picurl, String title, Integer userId,Integer width,Integer height);

    void deletepic(Integer id);

    List<Picture> findbytag(String tag);

    List<Picture> allpicture();

    List<Picture> searchbyuser(Integer userId);
}
