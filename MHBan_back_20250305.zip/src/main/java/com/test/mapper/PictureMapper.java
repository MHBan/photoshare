package com.test.mapper;

import com.test.pojo.Picture;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PictureMapper {
    @Insert("insert into picture (picurl,title,userid,width,height,createtime)" +
            " values(#{picurl},#{title},#{userId},#{width},#{height},now())")
    void createpicture(String picurl, String title, Integer userId,Integer width,Integer height);

    @Delete("delete from picture where id=#{id}")
    void deletepic(Integer id);

    @Select("select * from picture where title=#{title}")
    List<Picture> findbytag(String title);

    @Select("select * from picture")
    List<Picture> allpicture();

    @Select("select * from picture where userid=#{userid}")
    List<Picture> searchbyuser(Integer userId);
}
