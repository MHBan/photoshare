package com.test.mapper;

import com.test.pojo.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface UserMapper {
    @Select("select * from user where email=#{email}")
    User findByEmail(String email);

    @Insert("insert into user(password,name,email,createtime,updatetime)"+
    " values(#{password},#{name},#{email},now(),now())")
    void add(String name, String password, String email);

    @Update("update user set name=#{name},updateTime=now() where id=#{id}")
    void update(User u);

    @Update("update user set password=#{md5String},updatetime=now() where id=#{id}")
    void updatePwd(String md5String, Integer id);

    @Update("update user set userpic=#{avatar},updatetime=now() where id=#{userId}")
    void updateAcatar(String avatar, Integer userId);
}
