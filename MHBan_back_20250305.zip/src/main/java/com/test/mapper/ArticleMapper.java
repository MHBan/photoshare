package com.test.mapper;

import com.test.pojo.Article;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface ArticleMapper {
    @Select("select * from article where userid=#{userId} and title=#{title}")
    Article findbyTitle(Integer userId,String title);
    @Insert("insert into article(picurl,title,content,userid,createtime)"+
            " values(#{picurl},#{title},#{content},#{userId},now())")
    void createArticle(String picurl, String title, String content, Integer userId);

    @Delete("delete from article where id=#{id}")
    void deletebyId(Integer id);
}
