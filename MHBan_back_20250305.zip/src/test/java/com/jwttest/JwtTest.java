package com.jwttest;

import com.auth0.jwt.JWT;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class JwtTest {
    @Test
    public void getPublicIP() {
        String ip = "";
        try {
            URL url = new URL("http://ifconfig.me");
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            ip = in.readLine();
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(ip);
    }

}